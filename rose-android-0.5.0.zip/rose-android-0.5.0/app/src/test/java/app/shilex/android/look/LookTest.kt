package app.shilex.android.look

import app.shilex.android.assistant.FaceExpression
import app.shilex.android.assistant.Mood
import app.shilex.android.assistant.OrbThemes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LookTest {
    @Test
    fun thereAreHundredDistinctThemes() {
        assertEquals(100, OrbThemes.all.size)
        assertEquals(100, OrbThemes.all.map { it.key }.toSet().size)
        assertEquals(100, OrbThemes.all.map { it.name }.toSet().size)
        assertEquals("ruby_classic", OrbThemes.all.first().key)
        assertEquals("Ruby Classic", OrbThemes.of("ruby_classic")?.name)
        assertNull(OrbThemes.of(OrbThemes.FOLLOW_MOOD))
    }

    @Test
    fun everyMoodHasAFaceInRange() {
        Mood.entries.forEach {
            val f = FaceExpression.of(it)
            assertTrue(it.key, f.eyeOpen in 0.3f..1.25f && f.blush in 0f..1f && f.smile in -1f..1f && f.browTilt in -1f..1f)
        }
        // Angry frowns inward, sad worries outward; happy smiles, sad doesn't.
        assertTrue(FaceExpression.of(Mood.Angry).browTilt > 0)
        assertTrue(FaceExpression.of(Mood.Sad).browTilt < 0)
        assertTrue(FaceExpression.of(Mood.Happy).smile > 0 && FaceExpression.of(Mood.Sad).smile < 0)
    }
}
