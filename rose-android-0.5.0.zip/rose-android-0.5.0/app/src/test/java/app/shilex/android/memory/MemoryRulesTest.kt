package app.shilex.android.memory

import app.shilex.android.task.Capabilities
import app.shilex.android.task.TurnTrust
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryRulesTest {
    private val notes = listOf(
        Note("Parked on level 2, pillar B7", 1_000L),
        Note("Shoe size is 9 UK", 2_000L),
        Note("Anita's birthday is 12 March", 3_000L),
    )

    @Test
    fun secretsAreNeverKept() {
        listOf(
            "my bank password is hunter2", "ATM PIN 4821", "UPI pin is 1234", "card 4111 1111 1111 1111",
            "the OTP was 552910",
        ).forEach { assertTrue(it, MemoryRules.looksSecret(it)) }
        listOf("Parked on level 2", "Shoe size is 9", "Wi-Fi router is in the hall", "Pinned the poster")
            .forEach { assertFalse(it, MemoryRules.looksSecret(it)) }
    }

    @Test
    fun notesAreFoundByTheirWords() {
        assertEquals("Parked on level 2, pillar B7", MemoryRules.find("where did I park", notes).first().text)
        assertEquals("Shoe size is 9 UK", MemoryRules.find("shoe size", notes).first().text)
        assertTrue(MemoryRules.find("passport", notes).isEmpty())
        // No words: the latest notes first.
        assertEquals("Anita's birthday is 12 March", MemoryRules.find("", notes).first().text)
    }

    @Test
    fun routinesAreFoundByName() {
        val all = listOf(MemoryRules.GOOD_MORNING, Routine("Good night", listOf("Alarm at 6:30")))
        assertEquals("Good night", MemoryRules.routine("good night!", all)?.name)
        assertEquals("Good morning", MemoryRules.routine("Good Morning", all)?.name)
        assertEquals("Good night", MemoryRules.routine("night", all)?.name)
        assertNull(MemoryRules.routine("workout", all))
        assertNull(MemoryRules.routine("", all))
    }

    @Test
    fun screenTextCannotPlantMemoriesOrRoutines() {
        val trust = TurnTrust()
        listOf("remember", "forget", "routine_save").forEach {
            assertEquals(it, TurnTrust.Verdict.Allow, trust.verdict(Capabilities.of(it)!!))
        }
        trust.after("ui_read")
        listOf("remember", "forget", "routine_save").forEach {
            assertEquals(it, TurnTrust.Verdict.AskUser, trust.verdict(Capabilities.of(it)!!))
        }
        // Looking things up and running a saved routine stay allowed.
        assertEquals(TurnTrust.Verdict.Allow, trust.verdict(Capabilities.of("recall")!!))
        assertEquals(TurnTrust.Verdict.Allow, trust.verdict(Capabilities.of("routine_run")!!))
    }

    @Test
    fun notesAreSortedIntoCategories() {
        assertEquals("places", MemoryRules.categorize("Parked on level 2"))
        assertEquals("dates", MemoryRules.categorize("Anita's birthday is 12 March"))
        assertEquals("health", MemoryRules.categorize("Allergic to peanuts"))
        assertEquals("preferences", MemoryRules.categorize("Shoe size is 9 UK"))
        assertEquals(MemoryRules.GENERAL, MemoryRules.categorize("The blue folder"))
    }

    @Test
    fun aNoteAboutTheSameThingReplacesTheOldOne() {
        val old = listOf(Note("Parked on level 2", 1_000L), Note("Shoe size is 9 UK", 2_000L))
        val merged = MemoryRules.merge(old, Note("Parked on level 3", 3_000L))
        assertEquals(listOf("Shoe size is 9 UK", "Parked on level 3"), merged.map { it.text })
        // A different note is added next to the others.
        assertEquals(3, MemoryRules.merge(old, Note("Wi-Fi router is in the hall", 4_000L)).size)
    }

    @Test
    fun aFullStoreDropsTheLeastUsefulNoteNotAnImportantOne() {
        val full = listOf(
            Note("alpha one", 1_000L, important = true),
            Note("beta two", 2_000L),
            Note("gamma three", 3_000L, uses = 9),
        )
        val merged = MemoryRules.merge(full, Note("delta four", 4_000L), max = 3)
        assertEquals(3, merged.size)
        assertTrue(merged.any { it.text == "alpha one" })
        assertTrue(merged.any { it.text == "gamma three" })
        assertTrue(merged.none { it.text == "beta two" })
    }

    @Test
    fun wordsWithTheSameMeaningFindTheNote() {
        val n = listOf(Note("Anita's birthday is 12 March", 1_000L), Note("Parked on level 2", 2_000L))
        assertEquals("Anita's birthday is 12 March", MemoryRules.find("anita bday", n).first().text)
        assertEquals("Parked on level 2", MemoryRules.find("where is my car", n).first().text)
    }

    @Test
    fun theDigestGroupsByCategory() {
        val d = MemoryRules.digest(listOf(Note("Parked on level 2", 1L, "places"), Note("Anita's birthday is 12 March", 2L, "dates", important = true)))
        assertTrue(d.indexOf("places:") < d.indexOf("dates:"))
        assertTrue(d.contains("(important) Anita's birthday"))
        assertEquals("Nothing remembered yet.", MemoryRules.digest(emptyList()))
    }
}
