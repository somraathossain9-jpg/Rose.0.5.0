package app.shilex.android.assistant

/**
 * How the face looks for a mood, as plain numbers (no drawing here, so it is unit-tested).
 * [browTilt]: + frowns (inner ends down), - worries (inner ends up). [browLift]: + raised.
 * [smile]: + smiles, - frowns. [eyeOpen]: 0.3 sleepy .. 1.2 wide. [blush]: 0..1.
 */
data class FaceExpression(val browTilt: Float, val browLift: Float, val smile: Float, val eyeOpen: Float, val blush: Float) {
    companion object {
        fun of(mood: Mood): FaceExpression = when (mood) {
            Mood.Normal -> FaceExpression(0f, 0f, 0.25f, 1f, 0.1f)
            Mood.Angry -> FaceExpression(0.9f, -0.2f, -0.5f, 0.85f, 0f)
            Mood.Funny -> FaceExpression(-0.1f, 0.3f, 1f, 0.9f, 0.3f)
            Mood.Lovely -> FaceExpression(-0.2f, 0.2f, 0.8f, 1.05f, 1f)
            Mood.Sad -> FaceExpression(-0.9f, 0f, -0.8f, 0.8f, 0f)
            Mood.Excited -> FaceExpression(0f, 0.6f, 1f, 1.15f, 0.5f)
            Mood.Sleepy -> FaceExpression(0f, -0.2f, 0f, 0.35f, 0f)
            Mood.Surprised -> FaceExpression(0f, 0.9f, 0f, 1.2f, 0f)
            Mood.Shy -> FaceExpression(-0.4f, 0f, 0.4f, 0.8f, 1f)
            Mood.Proud -> FaceExpression(0.2f, 0.1f, 0.6f, 0.8f, 0.2f)
            Mood.Confused -> FaceExpression(-0.5f, 0.3f, -0.2f, 1f, 0f)
            Mood.Calm -> FaceExpression(0f, 0f, 0.35f, 0.7f, 0f)
            Mood.Happy -> FaceExpression(0f, 0.3f, 1f, 0.9f, 0.4f)
            Mood.Cool -> FaceExpression(0.3f, 0f, 0.3f, 0.65f, 0f)
            Mood.Naughty -> FaceExpression(0.5f, 0.2f, 0.9f, 0.85f, 0.3f)
            Mood.Worried -> FaceExpression(-0.8f, 0.3f, -0.4f, 1f, 0f)
            Mood.Jealous -> FaceExpression(0.6f, 0f, -0.3f, 0.7f, 0f)
            Mood.Grateful -> FaceExpression(-0.3f, 0.1f, 0.7f, 0.9f, 0.6f)
            Mood.Curious -> FaceExpression(-0.2f, 0.6f, 0.1f, 1.15f, 0f)
            Mood.Annoyed -> FaceExpression(0.6f, -0.1f, -0.4f, 0.6f, 0f)
        }
    }
}
