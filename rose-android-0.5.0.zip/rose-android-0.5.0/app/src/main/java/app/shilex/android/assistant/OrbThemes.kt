package app.shilex.android.assistant

import android.content.Context
import androidx.compose.ui.graphics.Color
import app.shilex.android.data.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** One colour theme for the orb and the face: three colours, like a [Mood]. */
data class OrbTheme(val key: String, val name: String, val main: Color, val light: Color, val deep: Color)

/**
 * 100 orb colour themes: 20 hues in 5 styles. Built from numbers, so the list is always
 * complete and the keys never change. "mood" (no theme) means the colours follow ROSE's mood.
 */
object OrbThemes {
    const val FOLLOW_MOOD = "mood"

    private class Hue(val name: String, val degrees: Float)
    private class Style(val name: String, val saturation: Float, val value: Float)

    private val HUES = listOf(
        Hue("Ruby", 355f), Hue("Coral", 12f), Hue("Sunset", 28f), Hue("Amber", 42f), Hue("Gold", 52f),
        Hue("Lime", 80f), Hue("Leaf", 110f), Hue("Emerald", 145f), Hue("Mint", 165f), Hue("Teal", 178f),
        Hue("Cyan", 190f), Hue("Sky", 202f), Hue("Ocean", 215f), Hue("Cobalt", 226f), Hue("Indigo", 245f),
        Hue("Violet", 266f), Hue("Orchid", 290f), Hue("Magenta", 310f), Hue("Rose", 335f), Hue("Berry", 346f),
    )
    private val STYLES = listOf(
        Style("Classic", 0.75f, 0.95f),
        Style("Neon", 1.0f, 1.0f),
        Style("Soft", 0.45f, 0.95f),
        Style("Deep", 0.85f, 0.66f),
        Style("Pastel", 0.28f, 1.0f),
    )

    val all: List<OrbTheme> = HUES.flatMap { hue ->
        STYLES.map { style ->
            OrbTheme(
                key = "${hue.name}_${style.name}".lowercase(),
                name = "${hue.name} ${style.name}",
                main = Color.hsv(hue.degrees, style.saturation, style.value),
                light = Color.hsv((hue.degrees + 14f) % 360f, (style.saturation - 0.3f).coerceAtLeast(0.05f), 1f),
                deep = Color.hsv(hue.degrees, (style.saturation + 0.1f).coerceAtMost(1f), style.value * 0.4f),
            )
        }
    }

    fun of(key: String): OrbTheme? = all.firstOrNull { it.key == key }
}

/** How ROSE looks right now: the chosen colour theme (null = follow the mood) and the orb or the face. */
object LookBus {
    private val _theme = MutableStateFlow<OrbTheme?>(null)
    val theme: StateFlow<OrbTheme?> = _theme.asStateFlow()

    private val _face = MutableStateFlow(false)
    val face: StateFlow<Boolean> = _face.asStateFlow()

    /** Reads the saved choices; called when the app starts and after a change in Settings. */
    fun load(context: Context) {
        val s = Settings(context)
        _theme.value = OrbThemes.of(s.orbTheme)
        _face.value = s.avatar == Settings.AVATAR_FACE
    }
}
