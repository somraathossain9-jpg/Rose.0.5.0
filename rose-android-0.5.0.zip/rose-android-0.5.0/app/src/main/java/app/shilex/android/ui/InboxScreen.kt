package app.shilex.android.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.shilex.android.notify.AutoReply
import app.shilex.android.notify.Conversation
import app.shilex.android.notify.Inbox
import app.shilex.android.notify.InboxRules
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The Smart Inbox: new chats from WhatsApp, imo, Messenger, Telegram, Instagram and texts in one list, urgent first.
 * Each chat can get a drafted reply; nothing is sent until you tap Send. Kept in memory only.
 */
@Composable
fun InboxScreen() {
    val chats by Inbox.chats.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Inbox", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (chats.isNotEmpty()) TextButton(onClick = Inbox::clear) { Text("Clear") }
        }
        Text(
            "New messages from people, all apps in one place. Needs notification access (Settings). " +
                "Kept in memory only; nothing is sent until you tap Send.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 12.dp),
        )
        if (chats.isEmpty()) {
            Text("No new messages.", style = MaterialTheme.typography.bodyMedium, color = Muted, modifier = Modifier.padding(top = 24.dp))
            return
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(chats, key = { it.key }) { ChatCard(it) }
        }
    }
}

@Composable
private fun ChatCard(chat: Conversation) {
    val context = LocalContext.current
    var text by remember(chat.key, chat.draft) { mutableStateOf(chat.draft.orEmpty()) }
    Column(
        Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(chat.who, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (chat.priority == InboxRules.Priority.Urgent) Pill("Urgent", Warning)
            Pill(chat.app, Accent, dot = false)
        }
        Text(chat.messages.takeLast(3).joinToString("\n"), style = MaterialTheme.typography.bodyMedium)
        Text(
            (if (chat.unread > 1) "${chat.unread} new · " else "") + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(chat.lastAt)),
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
        )
        if (chat.draft != null) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Draft reply (edit if you like)") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        chat.note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = Warning) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            when {
                chat.drafting -> Text("Writing a draft…", style = MaterialTheme.typography.bodySmall, color = Muted)
                chat.draft != null -> Button(onClick = { AutoReply.send(context, chat.key, text) }, enabled = text.isNotBlank()) { Text("Send") }
                chat.replyId != null -> OutlinedButton(onClick = { AutoReply.draft(context, chat.key) }) { Text("Draft reply") }
            }
            TextButton(onClick = {
                context.packageManager.getLaunchIntentForPackage(chat.packageName)
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let(context::startActivity)
            }) { Text("Open") }
            TextButton(onClick = { Inbox.dismiss(chat.key) }) { Text("Dismiss") }
        }
    }
}
