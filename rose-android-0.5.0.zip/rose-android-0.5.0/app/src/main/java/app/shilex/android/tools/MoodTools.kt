package app.shilex.android.tools

import app.shilex.android.assistant.Mood
import app.shilex.android.assistant.MoodBus
import org.json.JSONObject

/** Lets the model colour the orb with how it feels. Changes nothing on the phone. */
object MoodTools {
    fun all(): List<PhoneTool> = listOf(SetMood)

    private object SetMood : PhoneTool {
        override val name = "set_mood"

        override fun declaration() = Schema.function(
            name,
            "Shows how you feel by changing the orb's colour. Call it silently at the start of every " +
                "reply, together with any other tool. Never mention it to the user.",
            Schema.string("mood", "How you feel in this reply.", required = true, choices = Mood.keys),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val mood = Mood.of(args.text("mood")) ?: Mood.Normal
            MoodBus.set(mood)
            return Results.done("ok")
        }
    }
}
