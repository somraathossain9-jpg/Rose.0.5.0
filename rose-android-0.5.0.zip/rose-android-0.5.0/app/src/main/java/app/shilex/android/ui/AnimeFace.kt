package app.shilex.android.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import app.shilex.android.assistant.FaceExpression
import app.shilex.android.assistant.LookBus
import app.shilex.android.assistant.MoodBus
import app.shilex.android.assistant.Phase
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * ROSE as a 3D-looking anime face, drawn in code (no image files). The hair takes the colour theme or the mood's
 * colour; the eyes, brows and mouth follow the mood ([FaceExpression]); the head sways a little and the eyes, nose and
 * mouth shift more than the outline, which gives the depth. It blinks, and moves its mouth while ROSE speaks.
 * Standby is a still frame, so it costs no battery.
 */
@Composable
fun AnimeFace(phase: Phase, modifier: Modifier = Modifier, level: Float = 0f) {
    val mood by MoodBus.mood.collectAsState()
    val theme by LookBus.theme.collectAsState()
    val hair by animateColorAsState(theme?.main ?: mood.main, tween(900), label = "hair")
    val hairLight by animateColorAsState(theme?.light ?: mood.light, tween(900), label = "hairLight")
    val hairDeep by animateColorAsState(theme?.deep ?: mood.deep, tween(900), label = "hairDeep")
    val face = FaceExpression.of(mood)
    val tilt by animateFloatAsState(face.browTilt, spring(), label = "tilt")
    val lift by animateFloatAsState(face.browLift, spring(), label = "lift")
    val smile by animateFloatAsState(face.smile, spring(), label = "smile")
    val open by animateFloatAsState(face.eyeOpen, spring(), label = "open")
    val blush by animateFloatAsState(face.blush, tween(600), label = "blush")
    val voice by animateFloatAsState(level, spring(), label = "voice")
    val moving = phase != Phase.Off
    val clock = if (moving) {
        rememberInfiniteTransition(label = "face").animateFloat(0f, 1f, infiniteRepeatable(tween(8_000, easing = LinearEasing), RepeatMode.Restart), label = "t").value
    } else {
        0f
    }
    val talk = if (phase == Phase.Speaking) {
        rememberInfiniteTransition(label = "talk").animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Restart), label = "m").value
    } else {
        0f
    }

    Canvas(modifier) {
        val u = size.minDimension / 2f
        val sway = if (moving) sin(clock * 2 * PI.toFloat()) else 0f
        val bob = if (moving) sin(clock * 4 * PI.toFloat()) * 0.012f * u else 0f
        val parallax = sway * 0.05f * u
        val c = Offset(center.x, center.y + bob)

        // Blink: eyes shut for a moment every few seconds.
        val b = (clock * 2f) % 1f
        val blink = if (moving && b > 0.95f) 1f - sin((b - 0.95f) / 0.05f * PI.toFloat()) else 1f
        val eyeScale = (open * blink).coerceIn(0.05f, 1.25f)
        val mouthOpen = when {
            phase == Phase.Speaking -> (0.25f + 0.45f * abs(sin(talk * 2 * PI.toFloat())) + 0.3f * abs(sin(talk * 5 * PI.toFloat()))).coerceIn(0f, 1f)
            else -> (voice * 0.5f).coerceIn(0f, 0.5f)
        }

        // Soft glow behind the head.
        drawCircle(Brush.radialGradient(listOf(hair.copy(alpha = 0.28f), Color.Transparent), c, u * 1.25f), u * 1.25f, c)

        // Hair behind the face.
        val back = Path().apply {
            moveTo(c.x - 0.70f * u, c.y + 0.35f * u)
            cubicTo(c.x - 0.95f * u, c.y - 0.30f * u, c.x - 0.70f * u, c.y - 0.98f * u, c.x, c.y - 0.98f * u)
            cubicTo(c.x + 0.70f * u, c.y - 0.98f * u, c.x + 0.95f * u, c.y - 0.30f * u, c.x + 0.70f * u, c.y + 0.35f * u)
            cubicTo(c.x + 0.75f * u, c.y + 0.80f * u, c.x + 0.45f * u, c.y + 0.95f * u, c.x, c.y + 0.90f * u)
            cubicTo(c.x - 0.45f * u, c.y + 0.95f * u, c.x - 0.75f * u, c.y + 0.80f * u, c.x - 0.70f * u, c.y + 0.35f * u)
            close()
        }
        drawPath(back, Brush.verticalGradient(listOf(hair, hairDeep), c.y - u, c.y + u))

        // The face: lit from the top left, darker towards the lower right, so it reads as round.
        val faceCenter = Offset(c.x + parallax * 0.3f, c.y + 0.10f * u)
        val faceTop = Offset(faceCenter.x - 0.55f * u, faceCenter.y - 0.64f * u)
        val faceSize = Size(1.10f * u, 1.26f * u)
        drawOval(
            Brush.radialGradient(
                0f to Color(0xFFFFF1E6), 0.65f to Color(0xFFFFDCC8), 1f to Color(0xFFEFB59F),
                center = Offset(faceCenter.x - 0.18f * u, faceCenter.y - 0.25f * u), radius = 0.95f * u,
            ),
            faceTop, faceSize,
        )

        // Cheeks.
        val blushAlpha = (0.15f + 0.45f * blush).coerceIn(0f, 0.7f)
        listOf(-1f, 1f).forEach { side ->
            val cheek = Offset(c.x + side * 0.31f * u + parallax * 0.9f, c.y + 0.30f * u)
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFF7F9E).copy(alpha = blushAlpha), Color.Transparent), cheek, 0.16f * u), 0.16f * u, cheek)
        }

        // Eyes.
        val dark = Color(0xFF2B1B2E)
        listOf(-1f, 1f).forEach { side ->
            val e = Offset(c.x + side * 0.26f * u + parallax * 1.3f, c.y + 0.08f * u)
            val rx = 0.155f * u
            val ry = 0.20f * u * eyeScale
            drawOval(Color.White, Offset(e.x - rx, e.y - ry), Size(rx * 2, ry * 2))
            val look = Offset(sway * 0.012f * u, 0.01f * u)
            val ix = 0.118f * u
            val iy = (0.17f * u * eyeScale).coerceAtMost(ry)
            val iris = Offset(e.x + look.x, e.y + look.y)
            drawOval(
                Brush.radialGradient(listOf(hairLight, hair, hairDeep), iris, ix * 1.2f),
                Offset(iris.x - ix, iris.y - iy), Size(ix * 2, iy * 2),
            )
            drawOval(dark, Offset(iris.x - ix * 0.5f, iris.y - iy * 0.55f), Size(ix, iy * 1.1f))
            if (eyeScale > 0.4f) {
                drawCircle(Color.White, 0.04f * u, Offset(iris.x - ix * 0.35f, iris.y - iy * 0.45f))
                drawCircle(Color.White.copy(alpha = 0.8f), 0.022f * u, Offset(iris.x + ix * 0.4f, iris.y + iy * 0.45f))
            }
            // Upper lid with a lash flick at the outer corner.
            drawArc(
                dark, 190f, 160f, false, Offset(e.x - rx, e.y - ry), Size(rx * 2, ry * 2),
                style = Stroke(width = 0.035f * u, cap = StrokeCap.Round),
            )
            drawLine(dark, Offset(e.x + side * rx * 0.95f, e.y - ry * 0.35f), Offset(e.x + side * rx * 1.3f, e.y - ry * 0.7f), 0.03f * u, StrokeCap.Round)

            // Brow: inner end moves with the mood's tilt, the whole brow with its lift.
            val by = e.y - 0.27f * u - lift * 0.06f * u
            val inner = Offset(e.x - side * 0.13f * u, by + tilt * 0.07f * u)
            val outer = Offset(e.x + side * 0.15f * u, by - tilt * 0.03f * u)
            drawLine(hairDeep, inner, outer, 0.035f * u, StrokeCap.Round)
        }

        // Nose: a tiny shadow, shifted most for depth.
        val nose = Offset(c.x + parallax * 1.6f, c.y + 0.27f * u)
        drawLine(Color(0xFFD9917B), nose, Offset(nose.x + 0.012f * u, nose.y + 0.035f * u), 0.018f * u, StrokeCap.Round)

        // Mouth.
        val m = Offset(c.x + parallax * 1.4f, c.y + 0.43f * u)
        val half = 0.11f * u
        if (mouthOpen > 0.08f) {
            val h = 0.03f * u + mouthOpen * 0.15f * u
            val lipCurve = smile * 0.03f * u
            val inside = Path().apply {
                moveTo(m.x - half, m.y)
                quadraticBezierTo(m.x, m.y - lipCurve, m.x + half, m.y)
                quadraticBezierTo(m.x + half * 0.6f, m.y + h * 1.6f, m.x, m.y + h * 1.7f)
                quadraticBezierTo(m.x - half * 0.6f, m.y + h * 1.6f, m.x - half, m.y)
                close()
            }
            drawPath(inside, Color(0xFF8E2C45))
            drawOval(Color(0xFFFF8FA3), Offset(m.x - half * 0.5f, m.y + h * 0.9f), Size(half, h * 0.7f))
            drawPath(inside, dark, style = Stroke(width = 0.02f * u, cap = StrokeCap.Round))
        } else {
            val curve = Path().apply {
                moveTo(m.x - half, m.y - smile * 0.01f * u)
                quadraticBezierTo(m.x, m.y + smile * 0.08f * u, m.x + half, m.y - smile * 0.01f * u)
            }
            drawPath(curve, dark, style = Stroke(width = 0.025f * u, cap = StrokeCap.Round))
        }

        // Hair in front: bangs over the forehead and a strand down each side.
        val bangs = Path().apply {
            moveTo(c.x - 0.64f * u + parallax * 0.3f, c.y - 0.02f * u)
            cubicTo(c.x - 0.85f * u, c.y - 0.95f * u, c.x + 0.85f * u, c.y - 0.95f * u, c.x + 0.64f * u + parallax * 0.3f, c.y - 0.02f * u)
            quadraticBezierTo(c.x + 0.50f * u, c.y - 0.30f * u, c.x + 0.30f * u, c.y - 0.28f * u)
            quadraticBezierTo(c.x + 0.24f * u, c.y - 0.46f * u, c.x + 0.06f * u, c.y - 0.30f * u)
            quadraticBezierTo(c.x - 0.04f * u, c.y - 0.47f * u, c.x - 0.20f * u, c.y - 0.30f * u)
            quadraticBezierTo(c.x - 0.30f * u, c.y - 0.45f * u, c.x - 0.38f * u, c.y - 0.27f * u)
            quadraticBezierTo(c.x - 0.52f * u, c.y - 0.30f * u, c.x - 0.64f * u + parallax * 0.3f, c.y - 0.02f * u)
            close()
        }
        drawPath(bangs, Brush.verticalGradient(listOf(hairLight, hair, hairDeep), c.y - 0.9f * u, c.y - 0.2f * u))
        listOf(-1f, 1f).forEach { side ->
            val strand = Path().apply {
                moveTo(c.x + side * 0.62f * u, c.y - 0.05f * u)
                quadraticBezierTo(c.x + side * 0.70f * u, c.y + 0.40f * u, c.x + side * 0.55f * u, c.y + 0.85f * u)
            }
            drawPath(strand, hair, style = Stroke(width = 0.11f * u, cap = StrokeCap.Round))
        }
        // A highlight band across the hair makes it glossy.
        val shine = Path().apply {
            moveTo(c.x - 0.45f * u, c.y - 0.55f * u)
            quadraticBezierTo(c.x - 0.1f * u, c.y - 0.80f * u, c.x + 0.30f * u, c.y - 0.62f * u)
        }
        drawPath(shine, Color.White.copy(alpha = 0.35f), style = Stroke(width = 0.05f * u, cap = StrokeCap.Round))
        drawPath(shine, lerp(hairLight, Color.White, 0.5f).copy(alpha = 0.25f), style = Stroke(width = 0.09f * u, cap = StrokeCap.Round))
    }
}
