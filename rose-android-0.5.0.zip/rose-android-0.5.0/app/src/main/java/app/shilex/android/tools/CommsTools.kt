package app.shilex.android.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import app.shilex.android.data.Settings
import app.shilex.android.notify.Replies
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import org.json.JSONObject
import java.util.Locale

/**
 * Calls and messages. Each one opens the right app with everything filled in and the
 * user taps Call or Send there, so the model never completes these on its own.
 */
object CommsTools {
    fun all(): List<PhoneTool> = listOf(CallContact, CallControl, WhatsAppSend, SmsSend)

    private val who = arrayOf(
        Schema.string("name", "Contact name as the user said it. Leave empty if they gave a number."),
        Schema.string("number", "Phone number, only if the user said one."),
        Schema.string("which", "Which of the contact's numbers, e.g. mobile, work, or the last digits."),
    )

    private object CallContact : PhoneTool {
        override val name = "call_contact"

        override fun declaration() = Schema.function(
            name,
            "Opens the phone dialer with a contact's number filled in; the user taps Call. " +
                "For a hands-free voice call (\"call Rahul on speaker\") set speaker to yes: once the call is up, the phone turns the speaker on.",
            *who,
            Schema.string("speaker", "\"yes\" for a call on speaker."),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val to = when (val r = Recipients.resolve(args, host, "call")) {
                is Recipients.Result.Found -> r
                is Recipients.Result.Answer -> return r.json
            }
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", to.number, null))
            val auto = Settings(host.context).autoAllowMessaging
            return host.openApp(
                intent,
                "Phone",
                if (auto) {
                    "The dialer will open with ${to.name} after you speak and the call is placed automatically. " +
                        "Don't say it is connected until the app's note says the Call button was pressed."
                } else {
                    "The dialer will open with ${to.name} after you speak; the user taps Call."
                },
            ) {
                val pressed = if (auto) SendCheck.autoCall(DIALERS) else null
                val speaker = if (args.text("speaker").equals("yes", ignoreCase = true)) SendCheck.speakerOn(DIALERS) else null
                listOfNotNull(pressed, speaker).joinToString(" ").ifEmpty { null }
            }
        }
    }

    /**
     * During a call: answer a ringing call, hang up, or turn the speaker on. ROSE can't hear or speak into the call
     * itself (Android doesn't give apps the call's audio); on speaker the user talks hands-free.
     */
    private object CallControl : PhoneTool {
        override val name = "call_control"

        override fun declaration() = Schema.function(
            name,
            "Controls a phone call: answer a ringing call, hang up, or put the call on speaker. For 'pick up', 'cut the call', 'speaker on'.",
            Schema.string("action", "What to do.", required = true, choices = listOf("answer", "hangup", "speaker")),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val action = args.text("action")
            if (action == "speaker") {
                val note = SendCheck.speakerOn(DIALERS, timeoutMs = 8_000L)
                    ?: return Results.failed("no_control", "Speaker needs phone control. Ask the user to tap Speaker on the call screen.")
                return Results.done(note)
            }
            val permission = android.Manifest.permission.ANSWER_PHONE_CALLS
            if (!host.hasPermission(permission)) {
                host.requestPermission(permission)
                return Results.needsPermission("Phone calls")
            }
            val telecom = host.context.getSystemService(android.telecom.TelecomManager::class.java)
                ?: return Results.failed("no_telecom", "This phone can't control calls from here.")
            return runCatching {
                when (action) {
                    "answer" -> {
                        telecom.acceptRingingCall()
                        Results.done("Answered the call. It is not on speaker unless you also ask for speaker.")
                    }
                    "hangup" -> if (android.os.Build.VERSION.SDK_INT >= 28 && telecom.endCall()) {
                        Results.done("The call was ended.")
                    } else {
                        Results.failed("no_call", "There was no call to end.")
                    }
                    else -> Results.failed("bad_action", "Say answer, hangup or speaker.")
                }
            }.getOrElse { Results.failed("refused", "Android didn't allow that: ${it.javaClass.simpleName}.") }
        }
    }

    private object WhatsAppSend : PhoneTool {
        override val name = "whatsapp_send"

        override fun declaration() = Schema.function(
            name,
            "Opens a WhatsApp chat with the message typed in; the user taps Send.",
            *who,
            Schema.string("message", "The message, in the user's words and language.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val message = args.text("message")
            if (message.isEmpty()) return Results.failed("no_message", "Ask what the message should say.")
            handsFree(args, WHATSAPP)?.let { return it }
            val to = when (val r = Recipients.resolve(args, host, "message")) {
                is Recipients.Result.Found -> r
                is Recipients.Result.Answer -> return r.json
            }
            val digits = internationalDigits(host.context, to.number)
                ?: return Results.failed("bad_number", "That number doesn't look complete. Ask for it with the country code.")
            val link = Uri.parse("https://api.whatsapp.com/send?phone=$digits&text=${Uri.encode(message)}")
            val intent = Intent(Intent.ACTION_VIEW, link)
            val auto = Settings(host.context).autoAllowMessaging
            return host.openApp(
                intent,
                "WhatsApp",
                if (auto) {
                    "WhatsApp will open with the message to ${to.name} after you speak and is sent automatically. " +
                        "It is not sent yet: never say it was sent unless the app tells you it saw it in the chat."
                } else {
                    "WhatsApp will open with the message to ${to.name} after you speak; the user checks it and taps Send. " +
                        "It is not sent yet: never say it was sent unless the app tells you it saw it in the chat."
                },
            ) { if (auto) SendCheck.autoSend(WHATSAPP, message) else SendCheck.watchWhatsApp(message) }
        }
    }

    private object SmsSend : PhoneTool {
        override val name = "sms_send"

        override fun declaration() = Schema.function(
            name,
            "Opens the Messages app with an SMS typed in; the user taps Send.",
            *who,
            Schema.string("message", "The message, in the user's words and language.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val message = args.text("message")
            if (message.isEmpty()) return Results.failed("no_message", "Ask what the message should say.")
            handsFree(args, SMS_APPS)?.let { return it }
            val to = when (val r = Recipients.resolve(args, host, "message")) {
                is Recipients.Result.Found -> r
                is Recipients.Result.Answer -> return r.json
            }
            val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", to.number, null))
                .putExtra("sms_body", message)
            val auto = Settings(host.context).autoAllowMessaging
            return host.openApp(
                intent,
                "Messages",
                if (auto) {
                    "Messages will open with the SMS to ${to.name} after you speak and is sent automatically."
                } else {
                    "Messages will open with the SMS to ${to.name} after you speak; the user taps Send."
                },
            ) { if (auto) SendCheck.autoSend(SMS_APPS, message) else null }
        }
    }

    /** E.164 digits without "+", using the SIM's country for local numbers. */
    private fun internationalDigits(context: Context, number: String): String? {
        val telephony = context.getSystemService(TelephonyManager::class.java)
        val region = (telephony?.simCountryIso?.takeIf { it.isNotEmpty() } ?: Locale.getDefault().country)
            .uppercase()
        val e164 = PhoneNumberUtils.formatNumberToE164(number, region)
            ?: number.takeIf { it.trim().startsWith("+") }
        return e164?.filter(Char::isDigit)?.takeIf { it.length >= 8 }
    }
}

/** Turns "Rahul" / "Rahul's work number" / a spoken number into one number, or a question. */
/**
 * If [args]' person just messaged in one of [packages] and the notification has a Reply box,
 * the answer goes through it hands-free (Replies) instead of opening the app.
 */
private fun handsFree(args: JSONObject, packages: Set<String>): JSONObject? {
    val name = args.text("name")
    val id = Replies.idFor(name, packages, System.currentTimeMillis()) ?: return null
    return Results.failed(
        "use_reply",
        "$name just messaged and can be answered without opening the app: call reply_prepare with reply_id $id " +
            "and this message, read its line back and wait for the user's yes.",
    )
}

private val WHATSAPP = setOf("com.whatsapp", "com.whatsapp.w4b")
private val SMS_APPS = setOf("com.google.android.apps.messaging", "com.samsung.android.messaging")
private val DIALERS = setOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer", "com.android.server.telecom")

object Recipients {
    sealed interface Result {
        data class Found(val name: String, val number: String) : Result
        data class Answer(val json: JSONObject) : Result
    }

    fun resolve(args: JSONObject, host: ToolHost, verb: String): Result {
        val spoken = args.text("number")
        if (spoken.count(Char::isDigit) >= 6) return Result.Found(args.text("name").ifEmpty { spoken }, spoken)
        val name = args.text("name")
        if (name.isEmpty()) return Result.Answer(Results.failed("no_recipient", "Ask who to $verb."))
        if (!host.hasPermission(ContactsReader.PERMISSION)) {
            host.requestPermission(ContactsReader.PERMISSION)
            return Result.Answer(Results.needsPermission("Contacts"))
        }
        val matches = ContactsReader(host.context).search(name)
        return when {
            matches.isEmpty() -> Result.Answer(
                Results.failed("not_found", "No contact called $name. Ask the user to spell it or say the number."),
            )
            matches.size > 1 -> Result.Answer(
                Results.ask("Several contacts match \"$name\". Ask which one.", matches.take(6).map { it.name }),
            )
            else -> pick(matches.single(), args.text("which"))
        }
    }

    /** One contact: its only number, the one [which] names, or a question. */
    fun pick(contact: Contact, which: String): Result {
        val numbers = contact.numbers
        if (numbers.isEmpty()) return Result.Answer(Results.failed("no_number", "${contact.name} has no phone number saved."))
        if (numbers.size == 1) return Result.Found(contact.name, numbers.single().number)
        val w = which.lowercase().trim()
        val chosen = if (w.isEmpty()) {
            emptyList()
        } else {
            numbers.filter { w in it.label || (w.any(Char::isDigit) && it.number.filter(Char::isDigit).endsWith(w.filter(Char::isDigit))) }
        }
        if (chosen.size == 1) return Result.Found(contact.name, chosen.single().number)
        return Result.Answer(
            Results.ask(
                "${contact.name} has several numbers. Ask which one.",
                numbers.map { "${it.label} ending ${it.number.filter(Char::isDigit).takeLast(4)}" },
            ),
        )
    }
}
