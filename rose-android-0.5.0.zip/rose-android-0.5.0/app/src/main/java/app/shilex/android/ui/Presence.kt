package app.shilex.android.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import app.shilex.android.assistant.LookBus
import app.shilex.android.assistant.Phase

/** How ROSE shows up on the home screen: the animated face or the orb, as chosen in Settings. */
@Composable
fun Presence(phase: Phase, modifier: Modifier = Modifier, level: Float = 0f) {
    val face by LookBus.face.collectAsState()
    if (face) AnimeFace(phase, modifier, level) else Orb(phase, modifier, level)
}
