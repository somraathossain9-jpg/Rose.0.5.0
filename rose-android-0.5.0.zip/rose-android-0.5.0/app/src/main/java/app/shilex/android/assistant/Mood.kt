package app.shilex.android.assistant

import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** How ROSE feels right now. The orb takes its colours from it; [key] is what the model says. */
enum class Mood(val key: String, val main: Color, val light: Color, val deep: Color) {
    Normal("normal", Color(0xFF4F7BFF), Color(0xFF8B7CF6), Color(0xFF243B8F)),
    Angry("angry", Color(0xFFFF3B30), Color(0xFFFF8A65), Color(0xFF7A0C0C)),
    Funny("funny", Color(0xFF34C759), Color(0xFFB6F27A), Color(0xFF0B5A2A)),
    Lovely("lovely", Color(0xFFFF5FA8), Color(0xFFFFB3D9), Color(0xFF8A1E5C)),
    Sad("sad", Color(0xFF7E57C2), Color(0xFFB39DDB), Color(0xFF2E1A5E)),
    Excited("excited", Color(0xFFFF9500), Color(0xFFFFD166), Color(0xFF8A3B00)),
    Sleepy("sleepy", Color(0xFF7C8FD6), Color(0xFFB8C4F0), Color(0xFF2A3262)),
    Surprised("surprised", Color(0xFFFFE066), Color(0xFFFFFFFF), Color(0xFF9A7B00)),
    Shy("shy", Color(0xFFFFB3C7), Color(0xFFFFE0EA), Color(0xFFB04A6E)),
    Proud("proud", Color(0xFFE6B422), Color(0xFFFFE9A0), Color(0xFF6B4E00)),
    Confused("confused", Color(0xFF9AA5B1), Color(0xFFD0D6DD), Color(0xFF424B56)),
    Calm("calm", Color(0xFF26C6B0), Color(0xFF9FF0E3), Color(0xFF0B5C52)),
    Happy("happy", Color(0xFFFFD60A), Color(0xFFFFF3A0), Color(0xFF8A6A00)),
    Cool("cool", Color(0xFF29B6F6), Color(0xFFA5E8FF), Color(0xFF0B4F73)),
    Naughty("naughty", Color(0xFFD946EF), Color(0xFFF5A3FF), Color(0xFF6B1480)),
    Worried("worried", Color(0xFFC98A4B), Color(0xFFEBC79A), Color(0xFF5E3A14)),
    Jealous("jealous", Color(0xFF2E9E5B), Color(0xFF9BD9B0), Color(0xFF0C4A29)),
    Grateful("grateful", Color(0xFFFF8C69), Color(0xFFFFCDB8), Color(0xFF8A3A20)),
    Curious("curious", Color(0xFF00BFA5), Color(0xFF80F0E0), Color(0xFF3B1E8A)),
    Annoyed("annoyed", Color(0xFFE5533D), Color(0xFFF2A48F), Color(0xFF5C1D12));

    companion object {
        val keys: List<String> = entries.map { it.key }
        fun of(key: String): Mood? = entries.firstOrNull { it.key == key.trim().lowercase() }
    }
}

/** The current mood, shared by the voice session (which sets it) and the orbs (which show it). */
object MoodBus {
    private val _mood = MutableStateFlow(Mood.Normal)
    val mood: StateFlow<Mood> = _mood.asStateFlow()

    fun set(mood: Mood) {
        _mood.value = mood
    }

    fun reset() {
        _mood.value = Mood.Normal
    }
}
