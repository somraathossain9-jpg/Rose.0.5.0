package app.shilex.android.memory

/**
 * Something the user asked ROSE to remember. [category] groups it (see [MemoryRules.categorize]),
 * [important] notes are the last to be dropped when the store is full, and [uses] counts how often
 * it was found again, so what the user actually asks about stays.
 */
data class Note(
    val text: String,
    val atMillis: Long,
    val category: String = MemoryRules.GENERAL,
    val important: Boolean = false,
    val uses: Int = 0,
)

/** A named list of plain-language steps ("Good morning"), run with the normal tools and approvals. */
data class Routine(val name: String, val steps: List<String>)

/**
 * What may be remembered and how notes are found again. Pure, so it is unit-tested.
 * Secrets are never stored: a note that looks like a password, PIN, OTP or card number is
 * refused, because notes are sent to Gemini when recalled.
 */
object MemoryRules {
    private val SECRET_WORDS = Regex(
        """\b(password|passcode|pass word|pin|otp|cvv|upi pin|atm pin|secret|private key|seed phrase|login code)\b""",
        RegexOption.IGNORE_CASE,
    )
    private val CARD = Regex("""\b(?:\d[ -]?){13,19}\b""")
    private val STOP = setOf(
        "the", "a", "an", "my", "i", "is", "was", "where", "what", "did", "do", "to", "of", "in", "on", "at",
        "that", "this", "me", "remember", "about", "kya", "kaha", "kahan", "hai", "tha", "mera", "meri", "ka", "ki", "ke",
    )

    const val MAX_NOTES = 200
    const val MAX_LENGTH = 300
    const val MAX_ROUTINES = 20
    const val MAX_STEPS = 10

    const val GENERAL = "general"

    /** Category names in the order they are listed. */
    val CATEGORIES = listOf("people", "places", "dates", "preferences", "health", "work", GENERAL)

    private val CATEGORY_WORDS = linkedMapOf(
        "dates" to Regex("""\b(birthday|bday|anniversary|deadline|exam|due|\d{1,2}(st|nd|rd|th)? (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec))|জন্মদিন""", RegexOption.IGNORE_CASE),
        "health" to Regex("""\b(allerg\w*|medicine|tablet|pill|doctor|blood|diabet\w*|asthma|dose)\b|ওষুধ""", RegexOption.IGNORE_CASE),
        "places" to Regex("""\b(parked|parking|park|address|lives|live|hall|room|shelf|drawer|locker|keys?|kept|rakha)\b|রাখা""", RegexOption.IGNORE_CASE),
        "preferences" to Regex("""\b(like|likes|love|loves|favou?rite|prefer\w*|hate|size|diet|vegetarian|vegan|pasand)\b|পছন্দ""", RegexOption.IGNORE_CASE),
        "work" to Regex("""\b(office|meeting|boss|client|project|manager|salary|work|job)\b""", RegexOption.IGNORE_CASE),
        "people" to Regex("""\b(mom|mother|dad|father|brother|sister|wife|husband|friend|uncle|aunt|cousin|amma|abbu|bhai|apu|ma|baba)\b""", RegexOption.IGNORE_CASE),
    )

    /** Which category a note belongs to, by its words. Pure; [GENERAL] when nothing fits. */
    fun categorize(text: String): String = CATEGORY_WORDS.entries.firstOrNull { it.value.containsMatchIn(text) }?.key ?: GENERAL

    /** Words that mean the same when asked about ("park" finds "parked", "bday" finds "birthday"). */
    private val SAME = listOf(
        setOf("park", "parked", "parking", "gaadi", "car"),
        setOf("birthday", "bday", "janmadin", "জন্মদিন"),
        setOf("shoe", "shoes", "jute", "জুতা"),
        setOf("medicine", "tablet", "pill", "ওষুধ", "dawai"),
        setOf("mom", "mother", "amma", "ma", "মা"),
        setOf("dad", "father", "abbu", "baba", "বাবা"),
        setOf("key", "keys", "chabi"),
        setOf("wifi", "router", "internet"),
    )

    private fun related(word: String): Set<String> = SAME.firstOrNull { word in it } ?: emptySet()

    /** Notes about the same thing: most of the shorter note's words appear in the other. */
    fun similar(a: String, b: String): Boolean {
        val x = words(a).filter { it.length > 1 && it !in STOP }.toSet()
        val y = words(b).filter { it.length > 1 && it !in STOP }.toSet()
        if (x.isEmpty() || y.isEmpty()) return false
        val shared = x.intersect(y).size
        return shared.toDouble() / minOf(x.size, y.size) >= 0.8
    }

    /**
     * Adds [note] to [notes]: a note about the same thing replaces the old one (so "parked on level 3" updates
     * "parked on level 2"), and when the store is full the least useful note goes, never an important one
     * while others remain. Pure, so it is unit-tested.
     */
    fun merge(notes: List<Note>, note: Note, max: Int = MAX_NOTES): List<Note> {
        val old = notes.firstOrNull { similar(it.text, note.text) }
        val kept = if (old == null) notes else notes - old
        val added = if (old == null) note else note.copy(important = note.important || old.important, uses = old.uses)
        val all = kept + added
        if (all.size <= max) return all
        val drop = all.filter { it !== added }.minWithOrNull(compareBy<Note> { it.important }.thenBy { value(it) }) ?: return all
        return all - drop
    }

    /** How worth keeping a note is: used often and recent beats old and never asked about. */
    private fun value(note: Note): Long = note.uses * 7L * DAY + note.atMillis

    private const val DAY = 86_400_000L

    /** Notes grouped by category, in [CATEGORIES] order, important first inside each group. */
    fun digest(notes: List<Note>): String {
        if (notes.isEmpty()) return "Nothing remembered yet."
        return CATEGORIES.mapNotNull { cat ->
            val inCat = notes.filter { it.category == cat }.sortedWith(compareByDescending<Note> { it.important }.thenByDescending { it.atMillis })
            if (inCat.isEmpty()) null else cat + ":\n" + inCat.joinToString("\n") { "- " + (if (it.important) "(important) " else "") + it.text }
        }.joinToString("\n")
    }

    fun looksSecret(text: String) = SECRET_WORDS.containsMatchIn(text) || CARD.containsMatchIn(text)

    /** Notes that share words with [query], best first; all notes (newest first) for an empty query. */
    fun find(query: String, notes: List<Note>, limit: Int = 5): List<Note> {
        val wanted = words(query)
        if (wanted.isEmpty()) return notes.sortedByDescending { it.atMillis }.take(limit)
        val askedAbout = wanted.filter { it !in STOP }.ifEmpty { wanted }
        return notes
            .map { note ->
                val noteWords = words(note.text)
                val direct = noteWords.count { w -> askedAbout.any { q -> w.startsWith(q) || q.startsWith(w) } }
                val meaning = noteWords.count { w -> askedAbout.any { q -> w != q && w in related(q) } }
                val category = if (askedAbout.any { q -> q == note.category || q == note.category.removeSuffix("s") }) 1 else 0
                note to (direct * 10 + meaning * 6 + category * 4)
            }
            .filter { it.second > 0 }
            .map { (note, score) -> note to score + (if (note.important) 3 else 0) + minOf(note.uses, 5) }
            .sortedWith(compareByDescending<Pair<Note, Int>> { it.second }.thenByDescending { it.first.atMillis })
            .take(limit)
            .map { it.first }
    }

    /** "Good Morning!" and "good morning" are the same routine. */
    fun key(name: String) = name.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** The routine called [name], or the one whose name contains it. */
    fun routine(name: String, all: List<Routine>): Routine? {
        val k = key(name)
        if (k.isEmpty()) return null
        return all.firstOrNull { key(it.name) == k } ?: all.firstOrNull { key(it.name).contains(k) || k.contains(key(it.name)) }
    }

    /** Built in until the user saves their own with the same name. */
    val GOOD_MORNING = Routine(
        "Good morning",
        listOf("Say the date and time", "Today's weather", "What I missed (messages, calls, emails)", "Today's calendar"),
    )

    private fun words(text: String) = text.lowercase().split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.length >= 2 && it !in STOP }
}
