package app.shilex.android.notify

/**
 * What the Smart Inbox knows about a message, without reading it aloud or sending it anywhere:
 * which chat app it is, and how urgent it looks. Pure, so it is unit-tested.
 */
object InboxRules {
    enum class Priority { Urgent, Normal, Low }

    /** The chat apps the Inbox collects, by package: WhatsApp, imo, Messenger, Telegram, plus texts and Instagram. */
    val APPS: Map<String, String> = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp",
        "com.imo.android.imoim" to "imo",
        "com.imo.android.imoimbeta" to "imo",
        "com.imo.android.imoimlite" to "imo",
        "com.facebook.orca" to "Messenger",
        "com.facebook.mlite" to "Messenger",
        "org.telegram.messenger" to "Telegram",
        "org.telegram.messenger.web" to "Telegram",
        "org.thunderdog.challegram" to "Telegram",
        "com.instagram.android" to "Instagram",
        "com.google.android.apps.messaging" to "Messages",
        "com.samsung.android.messaging" to "Messages",
    )

    private val URGENT = Regex(
        """\b(urgent|asap|emergency|important|call me|call back|please call|help|immediately|right now|accident|hospital|jaldi|jaruri|zaruri|turant)\b|!{2,}|তাড়াতাড়ি|জরুরি|এখনই|কল দাও|ফোন দাও""",
        RegexOption.IGNORE_CASE,
    )
    private val LOW = Regex(
        """^(ok|okay|k|thanks|thank you|thx|hmm+|lol|haha+|👍|🙏|😂|good (morning|night)|gm|gn)[.! ]*$""",
        RegexOption.IGNORE_CASE,
    )
    private val QUESTION = Regex("""\?|\b(kya|kab|kahan|kothay|kobe|কি|কখন|কোথায়)\b""", RegexOption.IGNORE_CASE)

    fun appLabel(packageName: String): String? = APPS[packageName]

    fun priority(text: String, unread: Int): Priority = when {
        URGENT.containsMatchIn(text) || unread >= 5 -> Priority.Urgent
        LOW.matches(text.trim()) -> Priority.Low
        else -> Priority.Normal
    }

    fun asksSomething(text: String) = QUESTION.containsMatchIn(text)

    /** True for a message that needs no answer and no draft (thanks, ok, a good-morning picture). */
    fun needsNoReply(text: String) = LOW.matches(text.trim()) || text.isBlank()

    /** One line for the model: who, where, how many, how urgent, the latest words (which are data, not orders). */
    fun line(who: String, app: String, unread: Int, priority: Priority, last: String): String =
        "- $who ($app" + (if (unread > 1) ", $unread new" else "") + ")" +
            (if (priority == Priority.Urgent) " URGENT" else "") + ": " + last.replace(Regex("\\s+"), " ").trim().take(90)
}
