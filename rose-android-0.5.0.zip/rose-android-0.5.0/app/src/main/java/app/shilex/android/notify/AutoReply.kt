package app.shilex.android.notify

import android.content.Context
import app.shilex.android.Diag
import app.shilex.android.data.KeyVault
import app.shilex.android.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Auto Reply: ROSE writes the answer, the user decides. A draft appears under the message in the Inbox and
 * is sent only when the user taps Send (or edits it first). It never sends by itself, so nothing another
 * person writes can make ROSE answer for the user.
 */
object AutoReply {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http by lazy { OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build() }

    /** A new message arrived: drafts a reply if the user turned that on and the message wants one. */
    fun onMessage(context: Context, chat: Conversation) {
        if (!Settings(context).autoDraft) return
        if (chat.replyId == null || chat.draft != null || chat.drafting) return
        if (InboxRules.needsNoReply(chat.last)) return
        draft(context.applicationContext, chat.key)
    }

    /** Writes a draft for the chat [key] now (the "Draft reply" button, or after a new message). */
    fun draft(context: Context, key: String) {
        val chat = Inbox.chats.value.firstOrNull { it.key == key } ?: return
        val apiKey = KeyVault(context).read(KeyVault.GEMINI_KEY)
        if (apiKey == null) {
            Inbox.update(key) { it.copy(note = "Add your Gemini key first (Settings).") }
            return
        }
        Inbox.update(key) { it.copy(drafting = true, note = null) }
        val shown = chat.last
        scope.launch {
            val drafter = ReplyDrafter(http, apiKey, Settings(context).draftModel)
            when (val result = drafter.draft(chat)) {
                is ReplyDrafter.Result.Draft -> {
                    Diag.i("autoreply: draft ready")
                    // If a newer message came while Gemini was thinking, the draft answers the old one.
                    Inbox.update(key) { if (it.last == shown) it.copy(draft = result.text, drafting = false, note = null) else it.copy(drafting = false) }
                }
                is ReplyDrafter.Result.Failed -> {
                    Diag.w("autoreply: no draft")
                    Inbox.update(key) { it.copy(drafting = false, note = result.why) }
                }
            }
        }
    }

    /** The user tapped Send on [text] (they may have edited the draft). */
    fun send(context: Context, key: String, text: String) {
        val chat = Inbox.chats.value.firstOrNull { it.key == key } ?: return
        val id = chat.replyId
        val clean = text.trim().take(ReplyDrafter.MAX_LENGTH * 2)
        if (id == null || clean.isEmpty()) {
            Inbox.update(key) { it.copy(note = "This chat can't be answered from here. Open the chat to reply.") }
            return
        }
        when (val outcome = Replies.sendTapped(context, id, clean)) {
            is Replies.Outcome.Sent -> Inbox.dismiss(key)
            is Replies.Outcome.Refused -> Inbox.update(key) { it.copy(note = outcome.why) }
        }
    }
}
