# Rose 0.5.0

# Changes in 0.5.0

- Orb colour themes: 100 (20 hues x 5 styles) in Settings -> Look, or "Follow mood" (ui/OrbThemes in assistant/).
- Animated face: ROSE can appear as a 3D-looking anime face (ui/AnimeFace) that blinks, speaks and shows her mood. Settings -> Look.
- Smart memory: categories, "important" notes, a note about the same thing replaces the old one, better search
  (same-meaning words, Bangla/Banglish), notes that are used stay when the store is full, memory_digest tool.
- Smart Inbox: new tab; WhatsApp, imo, Messenger, Telegram, Instagram and text chats in one list, urgent first
  (notify/Inbox, InboxRules); inbox_summary tool. In memory only.
- Auto Reply: ROSE drafts a reply with Gemini (notify/ReplyDrafter, AutoReply); the user edits and taps Send.
  Never sends by itself. "Draft replies automatically" is off by default (it sends the message text to Gemini).
- Voice calls: call_contact can turn the speaker on once the call is up; call_control answers, hangs up or sets speaker.
  ROSE cannot hear or speak inside the call (Android doesn't give apps call audio).
- Instructions v10.

# Changes since the Jarvis -> Rose rename

- Voice picker (female voices first, default Kore), reply language incl. Bangla/Banglish, model name field (Settings).
- Bangla (bn-IN) added to speech recognition, so what you say appears in Bangla script.
- Talk over reacts sooner (TalkOver quick settings in VoiceSession).
- "Send and call without asking" (default off): only plain Send/Call in messaging apps and the dialer
  (ControlRules.autoAllowed). Payments, delete, OTP, passwords and banking apps still need you.
- Friendly mode: jokes, playful arguments, calls the owner Boss / Samrat Boss / Shrabon / Sir.
- 20 moods (assistant/Mood.kt) via the silent set_mood tool; the orb changes colour and has a 3D look (ui/Orb.kt).
- Instructions v9: careful listening and checking each tool result.
