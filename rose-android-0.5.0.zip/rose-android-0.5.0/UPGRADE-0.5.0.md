# ROSE 0.5.0: কীভাবে GitHub-এ তুলে build করবে

## আগে জানো (সৎ কথা)
- এই কোড আমি এখানে build করে দেখতে পারিনি (Android SDK ছিল না)। খাঁটি Kotlin অংশগুলো (Memory, Inbox, Orb Theme, Face
  expression) Kotlin compiler দিয়ে compile করে unit test চালিয়েছি: ১৭টা পাস। Compose UI, Android API আর network
  অংশ (AnimeFace, InboxScreen, ReplyDrafter, call tools) প্রথম build-এ ছোটখাটো error দিতে পারে। Actions-এর লগ
  দিলে ঠিক করে দেব।
- Voice Calling মানে: স্পিকারে কল, উত্তর দেওয়া, কেটে দেওয়া। কলের ভেতরে ROSE কথা শুনতে বা বলতে পারে না,
  কারণ Android কলের অডিও অ্যাপকে দেয় না।

## ধাপ
1. তোমার GitHub repo-র ফোল্ডারে পুরনো ফাইলগুলো মুছে এই zip-এর ভেতরের সব ফাইল (`rose-android-0.5.0/` এর ভেতরেরগুলো)
   বসাও। `.github` ফোল্ডারটাও যেন থাকে।
2. Commit আর push করো:
   `git add -A && git commit -m "ROSE 0.5.0" && git push`
3. GitHub → **Actions** ট্যাব → সর্বশেষ run খোলো। "Unit tests" ধাপ fail করলেও APK আটকায় না।
4. run শেষে নিচে **Artifacts** থেকে APK নামাও।
5. ফোনে আগের ROSE-এর ওপরেই install করো (একই signing key হলে settings থাকবে)।
   Debug key আলাদা হলে আগে পুরনোটা uninstall করতে হতে পারে।

## নতুন ফিচার চালু করা
- **Face / Orb রঙ:** Settings → Look।
- **Inbox:** Settings → Notifications থেকে Notification access দাও। তারপর Inbox ট্যাব।
- **Auto Reply:** Inbox-এর "Draft reply" বাটন, অথবা Settings → Inbox and Auto Reply → "Draft replies automatically"।
  Send সবসময় তোমার ট্যাপে যায়।
- **স্পিকারে কল:** Settings → Phone control চালু থাকতে হবে। বলো "Rahul-কে স্পিকারে কল করো"।
  "Pick up" / "cut the call" বললে প্রথমবার "Phone calls" permission চাইবে।
